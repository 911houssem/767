"""Small dependency-free smoke checks for project configuration."""
import ast
from pathlib import Path

APP = Path(__file__).parents[1] / "app" / "voice_agent_ui.py"

def test_python_file_parses():
    ast.parse(APP.read_text(encoding="utf-8"))

def test_health_route_exists():
    source = APP.read_text(encoding="utf-8")
    assert '@app.get("/health")' in source

def test_asr_modes_exist():
    source = APP.read_text(encoding="utf-8")
    assert 'ASR_BACKEND' in source
    assert '/audio/transcriptions' in source
